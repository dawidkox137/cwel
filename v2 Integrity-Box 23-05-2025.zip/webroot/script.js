const MODDIR = "/data/adb/modules/Integrity-Box";
const PROP = `${MODDIR}/module.prop`;

function isMMRL() {
  return navigator.userAgent.includes("com.dergoogler.mmrl");
}

function runShell(command) {
  if (isMMRL()) return Promise.reject("Not compatible with MMRL. Use KSUWebUI.");
  if (typeof ksu !== "object" || typeof ksu.exec !== "function")
    return Promise.reject("KernelSU JavaScript API not available.");
  const cb = `cb_${Date.now()}`;
  return new Promise((resolve, reject) => {
    window[cb] = (code, stdout, stderr) => {
      delete window[cb];
      code === 0 ? resolve(stdout) : reject(stderr || "Shell error");
    };
    ksu.exec(command, "{}", cb);
  });
}

function popup(msg) {
  return runShell(`am start -a android.intent.action.MAIN -e mona "${msg}" -n meow.helper/.MainActivity`);
}

async function getModuleName() {
  try {
    const name = await runShell(`grep '^name=' ${PROP} | cut -d= -f2`);
    document.getElementById("module-name").textContent = name.trim();
    document.title = name.trim();
  } catch {
    document.getElementById("module-name").textContent = "Integrity-Box";
  }
}

document.addEventListener("DOMContentLoaded", () => {
  getModuleName();

  document.querySelectorAll(".btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      const script = btn.dataset.script;
      runShell(`sh ${MODDIR}/${script}`);
    });
  });

  const toggle = document.getElementById("theme-toggle");
  const saved = localStorage.getItem("theme");
  if (saved === "dark") {
    document.documentElement.classList.add("dark");
    toggle.checked = true;
  }

  toggle.addEventListener("change", () => {
    document.documentElement.classList.toggle("dark", toggle.checked);
    localStorage.setItem("theme", toggle.checked ? "dark" : "light");
  });
});