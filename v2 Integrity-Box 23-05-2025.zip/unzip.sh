#!/system/bin/sh
# Check if the file exists
if [ -f /data/data/com.termux/files/usr/bin/openssl ]; then
    echo "- Installation type: DIRTY 🧹"
    echo "- Binary already exists, skipping files extraction"
    rm -f /data/adb/modules_update/Integrity-Box/binary.zip
else
    echo "- Installation type: FRESH💒"
    echo "- Extracting binaries to it's correct location..."
    
    rm -rf /data/data/com.termux
    
    # Ensure the parent directory exists before creating the target path
    if [ ! -d "/data/data/com.termux" ]; then
        echo "- Creating the necessary parent directory..."
        mkdir -p "/data/data/com.termux/files/"
    fi

    # Unzip the files
    if [ -f /data/adb/modules_update/Integrity-Box/binary.zip ]; then
    unzip -o /data/adb/modules_update/Integrity-Box/binary.zip -d /data/data/com.termux/files/ > /dev/null
elif [ -f /data/adb/modules/Integrity-Box/binary.zip ]; then
    unzip -o /data/adb/modules/Integrity-Box/binary.zip -d /data/data/com.termux/files/ > /dev/null
else
    echo "Zip file not found in both locations."
fi
    
    # Delete the zip file after extraction
#    rm -f /data/adb/modules_update/Integrity-Box/binary.zip
    
    echo "- Binary setup has been completed ❄️"
    echo " "
fi
