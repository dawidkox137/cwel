#!/system/bin/sh
  
# Remove the package cache & directory.
rm -rf /data/system/package_cache

# Define paths
SRC="/data/adb/modules/Integrity-Box/sus.sh"
DEST_DIR="/data/adb/modules/susfs4ksu"
DEST_FILE="$DEST_DIR/action.sh"

# Check if the destination directory exists
if [ ! -d "$DEST_DIR" ]; then
    echo "- Directory not found: $DEST_DIR. Exiting..."
    exit 0
fi

# Copy Copy 
cp "$SRC" "$DEST_FILE"

# Set perms
chmod +x "$DEST_FILE" 
chmod 644 "$DEST_FILE" 

rm -rf /data/adb/modules/Integrity-Box/disable
rm -rf /data/adb/shamiko/whitelist