rm -rf /data/adb/Integrity-Box
rm -rf /data/adb/tricky_store/keybox.xml
rm -rf /data/adb/tricky_store/target.txt
rm -rf /data/adb/modules/Integrity-Box
rm -rf /data/adb/modules/susfs4ksu/action.sh