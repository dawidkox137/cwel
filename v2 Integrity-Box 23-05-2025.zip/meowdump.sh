echo " "
nohup am start -a android.intent.action.VIEW -d https://t.me/MeowDump >/dev/null 2>&1 &
echo "Redirecting to 𝗠𝗘𝗢𝗪 𝗗𝗨𝗠𝗣"
exit 0